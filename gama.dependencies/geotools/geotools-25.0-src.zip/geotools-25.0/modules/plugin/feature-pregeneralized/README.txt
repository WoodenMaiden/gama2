Feature-Pregeneralizd module for Geotools                              

**  Build Issues  **

None 

** Tests **

No dependencies, run out of the box

