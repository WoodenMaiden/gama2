# IP Review:

STATUS: CLEAN

* Code: CLEAN
* Resources: CLEAN, no sample data included


## Second Review

Module contents replaced by Jody Garnett with implementation developed by Tom Kunicki for Boundless.

* org.geotools.mongodb:
  
  Provided under LGPL by Boundless, via OSGeo corporate license agreement.

## Initial Review

Initial module was added to the GeoTools project by Alan Mangan under the LGPL license.

* org.geotools.mongodb:

  Initial commit LGPL under OSGeo LGPL license.