# HANA JDBC Plugin

## Module Status

The module is stable.

## IP Review

Review incomplete - see [REVIEW.md](REVIEW.md).