GeoTools Extensions
===================

These extensions provide additional capabilities that are built on top of GeoTools using the spatial facilities of the library. The extensions are independent of each other offering and may be of use in your application.

For more information see the [GeoTools User Guide](https://docs.geotools.org/latest/userguide/welcome/architecture.html).