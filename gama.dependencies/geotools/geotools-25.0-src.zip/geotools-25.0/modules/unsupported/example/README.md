# Example Module

## Module Status

The example module is stable.

## IP Review

Review complete - see [REVIEW.md](REVIEW.md).