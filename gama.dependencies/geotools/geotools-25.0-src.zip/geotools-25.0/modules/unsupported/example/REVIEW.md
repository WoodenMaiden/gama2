# MODULE EXAMPLE

Module Maintainer: <YOUR NAME>

## IP Review:

 - <REVIEWER 1 NAME> - August 6th, 2006

 - <REVIEWER 2 NAME> - July 24th, 2007: removed dependencies on third party JDBC drivers

 - <REVIEWER 3 NAME> - June 2008: Initial commit as LGPL code

STATUS: Clean

```
org.geotools.example
```

 - Initial commit LGPL under OSGeo LGPL license.

```
org.geotools.example2
```

 - Header contains following reference to NASA:

---------------------------------------------------------------------------------
This file is derived from NGA/NASA software available for unlimited distribution.
See http://earth-info.nima.mil/GandG/wgs84/gravitymod/.
---------------------------------------------------------------------------------