# GeoTools WMS Map Tests
A JavaFX parent subclass containing a Canvas. A map from a WMS-Server is drawn to the Canvas using a StreamingRenderer.

## Module Status

In development.

## IP Review


## Used libraries:

Geotools ((C) 2008, Open Source Geospatial Foundation (OSGeo))

JFree FXGraphics2D (Copyright (c) 2014, Object Refinery Limited)
