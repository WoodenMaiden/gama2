# JavaFX Map Module

Module Maintainer: Alexander Woestmann (awoestmann@intevation.de)

## IP Review:

 - <REVIEWER 3 NAME> - Junde 2017: Initial commit

STATUS: In development

```
org.geotools.javafx
```

- Classes displaying the map.

