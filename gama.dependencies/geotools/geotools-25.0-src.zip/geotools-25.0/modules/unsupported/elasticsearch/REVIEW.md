Elastic Search Plugin
=====================

Module Maintainer: Stephen Gaffigan

IP Review
---------

* Jody Garnett, Marc 2020

STATUS: Clean.

* Use of GeoTools LGPL data structures and interfaces
* Public domain content from ElasticGeo contributed via software grant to Open Source Geospatial Foundation by Stephen Gaffigan (acting as a private individual).
  
  From the [ElasticGeo](https://github.com/ngageoint/elasticgeo) repository:

  > Software source code previously released under an open source license and then modified by NGA staff is considered a "joint work" (see 17 USC 101); it is partially copyrighted, partially public domain, and as a whole is protected by the copyrights of the non-government authors and must be released according to the terms of the original open source license.
